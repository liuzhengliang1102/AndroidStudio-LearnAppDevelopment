package com.example.savedatetest;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private final static String TAG = "lzl-test-MainActivity";
    private final static String COUNT_KEY = "COUNT_KEY";
    private final static String LIFECYCLELOG_KEY = "LIFECYCLELOG_KEY";

    private TextView mTextView;

    private TextView mTextViewCount;

    private int mClickCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mClickCount = 0;
        mTextView = (TextView) findViewById(R.id.textView_main);
        mTextViewCount = (TextView) findViewById(R.id.textViewCount);

        if (savedInstanceState != null) {
            String lifecycleLog = savedInstanceState.getString(LIFECYCLELOG_KEY, "空");
            mTextView.setText(lifecycleLog);
        } else {
            String string = String.format("你已点击【加1按键】次数：%d\n", mClickCount);
            mTextViewCount.setText(string);
        }

        if (Utils.isScreenOrientationPortrait(getApplicationContext())) {
            Utils.printLogAndTextViewShowLifecycle(mTextView, TAG, "当前状态为竖屏");
        } else {
            Utils.printLogAndTextViewShowLifecycle(mTextView, TAG, "当前状态为横屏");
        }
        Utils.printLogAndTextViewShowLifecycle(mTextView, TAG, "onCreate");
        findViewById(R.id.button_to_next).setOnClickListener(this);
        findViewById(R.id.button_add).setOnClickListener(this);
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        Utils.printLogAndTextViewShowLifecycle(mTextView, TAG, "onPostCreate");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Utils.printLogAndTextViewShowLifecycle(mTextView, TAG, "onRestart");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Utils.printLogAndTextViewShowLifecycle(mTextView, TAG, "onStart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Utils.printLogAndTextViewShowLifecycle(mTextView, TAG, "onResume");
    }

    @Override
    protected void onPostResume() {
        super.onPostResume();
        Utils.printLogAndTextViewShowLifecycle(mTextView, TAG, "onPostResume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Utils.printLogAndTextViewShowLifecycle(mTextView, TAG, "onPause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Utils.printLogAndTextViewShowLifecycle(mTextView, TAG, "onStop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Utils.printLogAndTextViewShowLifecycle(mTextView, TAG, "onDestroy");
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        String string = String.format("onSaveInstanceState: 你已点击【加1按键】次数：%d\n", mClickCount);
        Utils.printLogAndTextViewShowLifecycle(mTextView, TAG, string);

        outState.putInt(COUNT_KEY, mClickCount);
        outState.putString(LIFECYCLELOG_KEY, mTextView.getText().toString());
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        Utils.printLogAndTextViewShowLifecycle(mTextView, TAG, "onRestoreInstanceState");

        if (savedInstanceState != null) {
            int count = savedInstanceState.getInt(COUNT_KEY, 0);
            mClickCount = count;
            String string = String.format("你已点击【加1按键】次数：%d\n", mClickCount);
            Utils.printLogAndTextViewShowLifecycle(mTextView, TAG, string);
            mTextViewCount.setText(string);
        }
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        Utils.printLogAndTextViewShowLifecycle(mTextView, TAG, "onConfigurationChanged");
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.button_to_next) {
            Utils.printLogAndTextViewShowLifecycle(mTextView, TAG, "跳转到下一个页面");
            startActivity(new Intent(this, SecondaryActivity.class));
        } else if (v.getId() == R.id.button_add) {
            mClickCount = mClickCount + 1;
            String string = String.format("你已点击【加1按键】次数：%d\n", mClickCount);
            Utils.printLogAndTextViewShowLifecycle(mTextView, TAG, string);
            mTextViewCount.setText(string);
        }
    }
}