package com.example.savedatetest;

import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class SecondaryActivity extends AppCompatActivity implements View.OnClickListener {
    private final static String TAG = "lzl-test-SecondaryActivity";
    private final static String LIFECYCLELOG_KEY = "LIFECYCLELOG_KEY";

    private TextView mTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secondary);

        mTextView = (TextView) findViewById(R.id.textView_secondary);
        if (savedInstanceState != null) {
            String lifecycleLog = savedInstanceState.getString(LIFECYCLELOG_KEY, "空");
            mTextView.setText(lifecycleLog);
        }

        if (Utils.isScreenOrientationPortrait(getApplicationContext())) {
            Utils.printLogAndTextViewShowLifecycle(mTextView, TAG, "当前状态为竖屏");
        } else {
            Utils.printLogAndTextViewShowLifecycle(mTextView, TAG, "当前状态为横屏");
        }

        Utils.printLogAndTextViewShowLifecycle(mTextView, TAG, "onCreate");
        findViewById(R.id.button_return).setOnClickListener(this);
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        Utils.printLogAndTextViewShowLifecycle(mTextView, TAG, "onPostCreate");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Utils.printLogAndTextViewShowLifecycle(mTextView, TAG, "onRestart");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Utils.printLogAndTextViewShowLifecycle(mTextView, TAG, "onStart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Utils.printLogAndTextViewShowLifecycle(mTextView, TAG, "onResume");
    }

    @Override
    protected void onPostResume() {
        super.onPostResume();
        Utils.printLogAndTextViewShowLifecycle(mTextView, TAG, "onPostResume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Utils.printLogAndTextViewShowLifecycle(mTextView, TAG, "onPause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Utils.printLogAndTextViewShowLifecycle(mTextView, TAG, "onStop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Utils.printLogAndTextViewShowLifecycle(mTextView, TAG, "onDestroy");
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        Utils.printLogAndTextViewShowLifecycle(mTextView, TAG, "onSaveInstanceState");

        outState.putString(LIFECYCLELOG_KEY, mTextView.getText().toString());
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        Utils.printLogAndTextViewShowLifecycle(mTextView, TAG, "onRestoreInstanceState");
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        Utils.printLogAndTextViewShowLifecycle(mTextView, TAG, "onConfigurationChanged");
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.button_return) {
            Utils.printLogAndTextViewShowLifecycle(mTextView, TAG, "返回到上一页面");
            finish();
        }
    }
}