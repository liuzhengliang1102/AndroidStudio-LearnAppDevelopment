package com.example.startactivitymodetest;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private final static String TAG = "lzl-test-MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (Utils.isScreenOrientationPortrait(getApplicationContext())) {
            Utils.printLifecycle(TAG, "当前状态为竖屏");
        } else {
            Utils.printLifecycle(TAG, "当前状态为横屏");
        }
        Utils.printLifecycle(TAG, "onCreate");
        findViewById(R.id.button_goto_secondary).setOnClickListener(this);
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        Utils.printLifecycle(TAG, "onPostCreate");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Utils.printLifecycle(TAG, "onRestart");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Utils.printLifecycle(TAG, "onStart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Utils.printLifecycle(TAG, "onResume");
    }

    @Override
    protected void onPostResume() {
        super.onPostResume();
        Utils.printLifecycle(TAG, "onPostResume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Utils.printLifecycle(TAG, "onPause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Utils.printLifecycle(TAG, "onStop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Utils.printLifecycle(TAG, "onDestroy");
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        Utils.printLifecycle(TAG, "onSaveInstanceState");
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        Utils.printLifecycle(TAG, "onRestoreInstanceState");
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        Utils.printLifecycle(TAG, "onConfigurationChanged");
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.button_goto_secondary) {
            Utils.printLifecycle(TAG, "跳转到第二个页面");
            // 创建一个意图对象，准备跳到指定的活动页面
            Intent intent = new Intent(this, SecondaryActivity.class);
            // 当栈中存在待跳转的活动实例时，则重新创建该活动的实例，并清除原实例上方的所有实例
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); // 设置启动标志
            startActivity(intent);
        }
    }
}