package com.example.startactivitymodetest;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;

public class ThirdActivity extends AppCompatActivity implements View.OnClickListener {
    private final static String TAG = "lzl-test-ThirdActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

        if (Utils.isScreenOrientationPortrait(getApplicationContext())) {
            Utils.printLifecycle(TAG, "当前状态为竖屏");
        } else {
            Utils.printLifecycle(TAG, "当前状态为横屏");
        }

        Utils.printLifecycle(TAG, "onCreate");
        findViewById(R.id.button_return_home).setOnClickListener(this);
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        Utils.printLifecycle(TAG, "onPostCreate");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Utils.printLifecycle(TAG, "onRestart");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Utils.printLifecycle(TAG, "onStart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Utils.printLifecycle(TAG, "onResume");
    }

    @Override
    protected void onPostResume() {
        super.onPostResume();
        Utils.printLifecycle(TAG, "onPostResume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Utils.printLifecycle(TAG, "onPause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Utils.printLifecycle(TAG, "onStop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Utils.printLifecycle(TAG, "onDestroy");
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        Utils.printLifecycle(TAG, "onSaveInstanceState");
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        Utils.printLifecycle(TAG, "onRestoreInstanceState");
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        Utils.printLifecycle(TAG, "onConfigurationChanged");
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.button_return_home) {
            Utils.printLifecycle(TAG, "返回到主桌面页");
            finish();
        }
    }
}