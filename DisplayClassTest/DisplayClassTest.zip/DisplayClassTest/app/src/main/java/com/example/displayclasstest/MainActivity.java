package com.example.displayclasstest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.graphics.Point;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;
import android.view.WindowMetrics;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private final static String TAG = "lzl-test";
    private TextView mTextView;
    private StringBuilder mStringBuilder = new StringBuilder();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mTextView = (TextView) findViewById(R.id.textView);
        // 设置TextView内部文本的移动方式为滚动形式
        mTextView.setMovementMethod(new ScrollingMovementMethod());

        WindowManager windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        Display display = windowManager.getDefaultDisplay();

        Log.i(TAG, "getWidth():" + display.getWidth());
        Log.i(TAG, "getHeight():" + display.getHeight());
        mStringBuilder.append("getWidth():" + display.getWidth() + "\n");
        mStringBuilder.append("getHeight():" + display.getHeight() + "\n");

        mStringBuilder.append("\n");

        Point outSmallestSize = new Point();
        Point outLargestSize = new Point();
        display.getCurrentSizeRange(outSmallestSize, outLargestSize);
        Log.i(TAG, "getCurrentSizeRange():outSmallestSize:" + outSmallestSize.toString());
        Log.i(TAG, "getCurrentSizeRange():outLargestSize:" + outLargestSize.toString());
        mStringBuilder.append("getCurrentSizeRange():outSmallestSize:" + outSmallestSize.toString() + "\n");
        mStringBuilder.append("getCurrentSizeRange():outLargestSize:" + outLargestSize.toString() + "\n");

        mStringBuilder.append("\n");

        DisplayMetrics realDisplayMetrics = new DisplayMetrics();
        display.getRealMetrics(realDisplayMetrics);
        Log.i(TAG, "getRealMetrics():" + realDisplayMetrics.toString());
        double screenSize = Math.sqrt(Math.pow(realDisplayMetrics.widthPixels/realDisplayMetrics.xdpi,2) + Math.pow(realDisplayMetrics.heightPixels/realDisplayMetrics.ydpi,2));
        Log.i(TAG, "screenSize:" + screenSize);
        mStringBuilder.append("getRealMetrics():" + realDisplayMetrics.toString() + "\n");
        mStringBuilder.append("screenSize:" + screenSize + "\n");

        DisplayMetrics displayMetrics = new DisplayMetrics();
        display.getMetrics(displayMetrics);
        Log.i(TAG, "getMetrics():" + displayMetrics.toString());
        mStringBuilder.append("getMetrics():" + displayMetrics.toString() + "\n");

        mStringBuilder.append("\n");

        Point outSize = new Point();
        display.getRealSize(outSize);
        Log.i(TAG, "getRealSize():" + outSize.toString());
        mStringBuilder.append("getRealSize():" + outSize.toString() + "\n");

        display.getSize(outSize);
        Log.i(TAG, "getSize():" + outSize.toString());
        mStringBuilder.append("getSize():" + outSize.toString() + "\n");

        mStringBuilder.append("\n");

        Rect outRect = new Rect();
        display.getRectSize(outRect);
        Log.i(TAG, "getRectSize():" + outRect.toString());
        mStringBuilder.append("getRectSize():" + outRect.toString() + "\n");

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Display.Mode activeMode = null;
            activeMode = display.getMode();
            Log.i(TAG, "getMode():" + activeMode.toString());
            mStringBuilder.append("getMode():" + activeMode.toString() + "\n");
            mStringBuilder.append("\n");
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Display.Mode[] modes = display.getSupportedModes();
            for (int i = 0; i < modes.length; i++) {
                Log.i(TAG, "getSupportedModes():Mode[" + i + "]:"+ modes[i].toString());
                mStringBuilder.append("getSupportedModes():Mode[" + i + "]:"+ modes[i].toString() + "\n");
            }
            mStringBuilder.append("\n");
        }

        Log.i(TAG, "getDisplayId:" + display.getDisplayId());
        mStringBuilder.append("getDisplayId:" + display.getDisplayId() + "\n");
        Log.i(TAG, "getFlags:" + display.getFlags());
        mStringBuilder.append("getFlags:" + display.getFlags() + "\n");

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Display.HdrCapabilities hdrCapabilities = null;
            hdrCapabilities = display.getHdrCapabilities();
            if (hdrCapabilities != null) {
                Log.i(TAG, "getHdrCapabilities:" + hdrCapabilities.toString());
                mStringBuilder.append("getHdrCapabilities:" + hdrCapabilities.toString() + "\n");
            }
        }

        Log.i(TAG, "isValid:" + display.isValid());
        mStringBuilder.append("isValid:" + display.isValid() + "\n");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Log.i(TAG, "isHdr:" + display.isHdr());
            mStringBuilder.append("isHdr:" + display.isHdr() + "\n");
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Log.i(TAG, "isMinimalPostProcessingSupported:" + display.isMinimalPostProcessingSupported());
            mStringBuilder.append("isMinimalPostProcessingSupported:" + display.isMinimalPostProcessingSupported() + "\n");
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Log.i(TAG, "isWideColorGamut:" + display.isWideColorGamut());
            mStringBuilder.append("isWideColorGamut:" + display.isWideColorGamut() + "\n");
        }

        Log.i(TAG, "getName:" + display.getName());
        mStringBuilder.append("getName:" + display.getName() + "\n");

        Log.i(TAG, "getOrientation:" + display.getOrientation());
        mStringBuilder.append("getOrientation:" + display.getOrientation() + "\n");
        Log.i(TAG, "getRotation:" + display.getRotation());
        mStringBuilder.append("getRotation:" + display.getRotation() + "\n");
        Log.i(TAG, "getPixelFormat:" + display.getPixelFormat());
        mStringBuilder.append("getPixelFormat:" + display.getPixelFormat() + "\n");

        mStringBuilder.append("\n");

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            if (display.getPreferredWideGamutColorSpace() != null) {
                Log.i(TAG, "getPreferredWideGamutColorSpace:" + display.getPreferredWideGamutColorSpace().toString());
                mStringBuilder.append("getPreferredWideGamutColorSpace:" + display.getPreferredWideGamutColorSpace().toString() + "\n");
            }
        }
        Log.i(TAG, "getPresentationDeadlineNanos:" + display.getPresentationDeadlineNanos());
        mStringBuilder.append("getPresentationDeadlineNanos:" + display.getPresentationDeadlineNanos() + "\n");

        Log.i(TAG, "getRefreshRate:" + display.getRefreshRate());
        mStringBuilder.append("getRefreshRate:" + display.getRefreshRate() + "\n");

        Log.i(TAG, "getState:" + display.getState());
        mStringBuilder.append("getState:" + display.getState() + "\n");

        float [] refreshRates = display.getSupportedRefreshRates();
        for (int i = 0; i < refreshRates.length; i++) {
            Log.i(TAG, "refreshRates[" + i + "]:"+ refreshRates[i]);
            mStringBuilder.append("refreshRates[" + i + "]:"+ refreshRates[i] + "\n");
        }

        mStringBuilder.append("\n\n\n");

        Log.i(TAG, "getResources().getDisplayMetrics():" + getResources().getDisplayMetrics().toString());
        Log.i(TAG, " getResources().getDisplayMetrics():widthPixels:"
                + displayMetrics.widthPixels + ", heightPixels:" + displayMetrics.heightPixels);
        mStringBuilder.append("getResources().getDisplayMetrics():" + getResources().getDisplayMetrics().toString() + "\n");

        mStringBuilder.append("\n\n\n");

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            WindowMetrics windowMetrics = null;
            windowMetrics = windowManager.getCurrentWindowMetrics();
            Rect rect = windowMetrics.getBounds();
            Log.i(TAG, "getCurrentWindowMetrics():"+ rect.toString());
            Log.i(TAG, "getCurrentWindowMetrics(): width:"+ rect.width() + ", height:" + rect.height());
            mStringBuilder.append("getCurrentWindowMetrics():"+ rect.toString() + "\n");
            mStringBuilder.append("getCurrentWindowMetrics(): width:"+ rect.width() + ", height:" + rect.height() + "\n");
        }

        mTextView.setText(mStringBuilder.toString());
    }
}