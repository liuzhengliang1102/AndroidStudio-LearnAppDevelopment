package com.example.framerateapitest;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Service;
import android.content.pm.ActivityInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.hardware.display.DisplayManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Vibrator;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements
        View.OnClickListener,
        AdapterView.OnItemSelectedListener,
        SurfaceHolder.Callback,DisplayManager.DisplayListener {
    private static final String TAG = "lzl-test-FrameRateApiTest";
    private TextView mTextViewInfo;
    private Spinner mSpinnerSystem, mSpinnerSetFrameRate, mSpinnerPreferredDisplayModeId;
    private Button mButtonSetFrameRate, mButtonPreferredDisplayModeId;

    private Display mDisplay;
    private Display.Mode mActiveMode;

    private ArrayAdapter<Integer> mArrayAdapterSystem, mArrayAdapterSetFrameRate, mArrayAdapterPreferredDisplayModeId;
    private Integer[] mSystemSelectableFps, mPreferredDisplayModeIdelectableFps;
    private int mSystemSelectedFps = 0;
    private Integer[] mSetFrameRateSelectableFps = {1, 5, 10, 24, 25, 30, 40, 50, 60, 90, 120, 144};

    private SurfaceView mSurfaceView;
    private SurfaceHolder mSurfaceHolder;
    private Paint mPaint = new Paint();
    private int mCircleRadius = 10;
    private boolean isRunning = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d(TAG, "onCreate:---------------------------------------------------------start");

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_NOSENSOR); //设置屏幕不随手机旋转
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); //设置屏幕直向显示
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN); //设置屏幕不进入休眠
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); //设置屏幕不进入休眠

        /* 获取layout相关R.id.* */
        mTextViewInfo = (TextView) findViewById(R.id.textViewInfo);
        mSpinnerSystem = (Spinner) findViewById(R.id.spinnerSystem);
        mSpinnerSystem.setOnItemSelectedListener(this);
        mSpinnerSetFrameRate = (Spinner) findViewById(R.id.spinnerSetFrameRate);
        mSpinnerSetFrameRate.setOnItemSelectedListener(this);
        mSpinnerPreferredDisplayModeId = (Spinner) findViewById(R.id.spinnerPreferredDisplayModeId);
        mSpinnerPreferredDisplayModeId.setOnItemSelectedListener(this);

        mButtonSetFrameRate = (Button)findViewById(R.id.buttonSetFrameRate);
        mButtonSetFrameRate.setOnClickListener(this);
        mButtonPreferredDisplayModeId = (Button)findViewById(R.id.buttonPreferredDisplayModeId);
        mButtonPreferredDisplayModeId.setOnClickListener(this);

        mSurfaceView = (SurfaceView) findViewById(R.id.surfaceView);
        mSurfaceHolder = mSurfaceView.getHolder();
        mSurfaceHolder.addCallback(this);

        /* 获取DisplayManager */
        DisplayManager displayManager = (DisplayManager) getSystemService(Service.DISPLAY_SERVICE);
        /* 注册DisplayManager 的DisplayManager.DisplayListener 监听，监听display的变化，如添加/删除display，display帧率变化等 */
        displayManager.registerDisplayListener(this, null);

        mDisplay = getWindowManager().getDefaultDisplay();
        mActiveMode = mDisplay.getMode();
        Log.d(TAG, "getMode: " + mActiveMode.toString());
        mTextViewInfo = (TextView) findViewById(R.id.textViewInfo);
        mTextViewInfo.setText("系统当前帧率：" + (int) mActiveMode.getRefreshRate() + "Hz, 分辨率: " + mActiveMode.getPhysicalWidth() + " x " + mActiveMode.getPhysicalHeight());

        Display.Mode[] supportedModes = mDisplay.getSupportedModes();
        for (Display.Mode mode : supportedModes) {
            Log.d(TAG, "getSupportedModes: " + mode.toString());
        }

        float[] supportedRefreshRates = getWindowManager().getDefaultDisplay().getSupportedRefreshRates();
        for (float refreshRate: supportedRefreshRates) {
            Log.d(TAG, "SupportedRefreshRates: " + refreshRate);
        }
        mSystemSelectableFps = new Integer[supportedRefreshRates.length];
        mPreferredDisplayModeIdelectableFps = new Integer[supportedRefreshRates.length];
        for (int i = 0; i < supportedRefreshRates.length; i++) {
            mSystemSelectableFps[i] = (int) supportedRefreshRates[i];
            mPreferredDisplayModeIdelectableFps[i] = (int) supportedRefreshRates[i];
        }
        mArrayAdapterSystem = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, mSystemSelectableFps);
        mArrayAdapterSystem.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); // 设置下拉选单的选项样式
        mSpinnerSystem.setAdapter(mArrayAdapterSystem); // 设置使用 Adapter 对象
        for (int i = 0; i < mSystemSelectableFps.length; i++) {
            if (mSystemSelectableFps[i].intValue() == (int) mActiveMode.getRefreshRate()) {
                mSpinnerSystem.setSelection(i);
                break;
            }
        }
        mSpinnerSystem.setEnabled(false);

        mArrayAdapterSetFrameRate = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, mSetFrameRateSelectableFps);
        mArrayAdapterSetFrameRate.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); // 设置下拉选单的选项样式
        mSpinnerSetFrameRate.setAdapter(mArrayAdapterSetFrameRate); // 设置使用 Adapter 对象
        for (int i = 0; i < mSetFrameRateSelectableFps.length; i++) {
            if (mSetFrameRateSelectableFps[i].intValue() == 60) {
                mSpinnerSetFrameRate.setSelection(i);
                break;
            }
        }

        mArrayAdapterPreferredDisplayModeId = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, mPreferredDisplayModeIdelectableFps);
        mArrayAdapterPreferredDisplayModeId.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); // 设置下拉选单的选项样式
        mSpinnerPreferredDisplayModeId.setAdapter(mArrayAdapterPreferredDisplayModeId); // 设置使用 Adapter 对象
        for (int i = 0; i < mPreferredDisplayModeIdelectableFps.length; i++) {
            if (mPreferredDisplayModeIdelectableFps[i].intValue() == (int) mActiveMode.getRefreshRate()) {
                mSpinnerPreferredDisplayModeId.setSelection(i);
                break;
            }
        }
    }

    @Override
    public void onClick(View view) {
        int position = 0;
        int fps = 0;
        if (view.getId() == R.id.buttonSetFrameRate) {
            position = mSpinnerSetFrameRate.getSelectedItemPosition();
            fps = mSetFrameRateSelectableFps[position].intValue();
            Log.d(TAG, "Button: setFrameRate fps:" + fps);
            if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                mSurfaceHolder.getSurface().setFrameRate(fps,
                        Surface.FRAME_RATE_COMPATIBILITY_FIXED_SOURCE,
                        Surface.CHANGE_FRAME_RATE_ONLY_IF_SEAMLESS);
            }
        } else if (view.getId()  == R.id.buttonPreferredDisplayModeId) {
            position = mSpinnerPreferredDisplayModeId.getSelectedItemPosition();
            fps = mPreferredDisplayModeIdelectableFps[position].intValue();
            Log.d(TAG, "Button: preferredDisplayModeId fps:" + fps);
            int preferredDisplayModeId = 0;
            Display.Mode[] supportedModes = mDisplay.getSupportedModes();
            for (Display.Mode mode : supportedModes) {
                if ((int)mode.getRefreshRate() == fps &&
                        mode.getPhysicalWidth() == mActiveMode.getPhysicalWidth() &&
                        mode.getPhysicalHeight() == mActiveMode.getPhysicalHeight()) {
                    preferredDisplayModeId = mode.getModeId();
                }
            }

            if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                WindowManager.LayoutParams params = getWindow().getAttributes();
                params.preferredDisplayModeId = preferredDisplayModeId;
                getWindow().setAttributes(params);
            }
        } else {
            Log.e(TAG, "Unknown R.id!");
        }
    }

    // 开始绘制
    public void start() {
        isRunning = true;

        new Thread() {
            @Override
            public void run() {
                while (isRunning) {
                    drawCircle();
                    try {
                        /* 以最快1000/144hz = 7ms,如果系统帧率设置成功, 画圆的帧率会被拉低到系统帧率（由于dequeueBuffer等待）
                           所以从画圆的速度，能直观的观察帧率变化情况
                           如果有root权限：
                           adb shell service call SurfaceFlinger 1035 i32 xx（ModeID）
                           或者：settings put system peak_refresh_rate xx（RefreshRate）
                         */
                        Thread.sleep(7);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }.start();
    }

    // 停止绘制
    public void stop() {
        isRunning = false;
    }

    // 绘制图形
    private void drawCircle() {
        long now = System.currentTimeMillis();
        if (mSurfaceHolder != null) {
            Canvas canvas = mSurfaceHolder.lockCanvas();
            if (canvas != null) {
                canvas.drawARGB(255, 13, 61, 80);
                canvas.drawCircle(canvas.getWidth() / 2, canvas.getWidth() / 2, mCircleRadius, mPaint);

                if (mCircleRadius < canvas.getWidth() / 2) {
                    mCircleRadius++;
                } else {
                    mCircleRadius = 10;
                }
                if (canvas != null && mSurfaceHolder != null) {
                    mSurfaceHolder.unlockCanvasAndPost(canvas);
                }
            }
        }
    }

    @Override
    public void surfaceCreated(@NonNull SurfaceHolder surfaceHolder) {
        Log.d(TAG, "surfaceCreated...");
        if (mSurfaceHolder == null) {
            // 调用getHolder()方法获取SurfaceHolder
            mSurfaceHolder = mSurfaceView.getHolder();
            // 通过 SurfaceHolder.addCallback方法设置:实现SurfaceHolder.Callback回调接口
            mSurfaceHolder.addCallback(this);
        }
        mPaint.setAntiAlias(true); // 设置画笔为无锯齿
        mPaint.setColor(Color.RED); // 设置画笔的颜色
        mPaint.setStrokeWidth(10); // 设置画笔的线宽
        mPaint.setStyle(Paint.Style.FILL); // 设置画笔的类型。STROK表示空心，FILL表示实心
        mPaint.setTextSize(30);
        start();
    }

    @Override
    public void surfaceChanged(@NonNull SurfaceHolder surfaceHolder, int i, int i1, int i2) {
        Log.d(TAG, "surfaceChanged...");

    }

    @Override
    public void surfaceDestroyed(@NonNull SurfaceHolder surfaceHolder) {
        Log.d(TAG, "surfaceDestroyed...");
        mSurfaceHolder = null;
        isRunning = false;
        stop();

    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
        Log.d(TAG, "Spinner: onItemSelected: position = " + position + ", id = " + id);
        Spinner spinner = (Spinner) adapterView;
        if (spinner == mSpinnerSystem) {
            Log.d(TAG, "Spinner: System fps:" + mSystemSelectableFps[position].intValue());
        } else if (spinner == mSpinnerSetFrameRate) {
            Log.d(TAG, "Spinner: setFrameRate fps:" + mSetFrameRateSelectableFps[position].intValue());
        } else if (spinner == mSpinnerPreferredDisplayModeId) {
            Log.d(TAG, "Spinner: preferredDisplayModeId fps:" + mPreferredDisplayModeIdelectableFps[position].intValue());
        } else {
            Log.e(TAG, "Unknown spinner id!");
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {
        Log.d(TAG, "onNothingSelected...");

    }

    @Override
    public void onDisplayAdded(int displayId) {
        Log.d(TAG, "onDisplayAdded...");

    }

    @Override
    public void onDisplayRemoved(int displayId) {
        Log.d(TAG, "onDisplayRemoved...");

    }

    @Override
    public void onDisplayChanged(int displayId) {
        Log.d(TAG, "onDisplayChanged...");
        mActiveMode = mDisplay.getMode();
        mTextViewInfo.setText("系统当前帧率：" + (int) mActiveMode.getRefreshRate() + "Hz, 分辨率: " + mActiveMode.getPhysicalWidth() + " x " + mActiveMode.getPhysicalHeight());

        for (int i = 0; i < mSystemSelectableFps.length; i++) {
            if (mSystemSelectableFps[i].intValue() == (int) mActiveMode.getRefreshRate()) {
                mSpinnerSystem.setSelection(i);
                break;
            }
        }
    }

    @Override
    public void onResume() {
        Log.d(TAG, "onResume...");
        super.onResume();
    }

    @Override
    public void onPause() {
        Log.d(TAG, "onResume...");
        super.onPause();
    }

    @Override
    public void onStop() {
        Log.d(TAG, "onResume...");
        super.onStop();
    }

    @Override
    public void onDestroy() {
        Log.d(TAG, "onResume...");
        super.onDestroy();
    }
}
