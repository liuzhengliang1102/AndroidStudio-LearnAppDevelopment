package com.example.refreshratesurfaceviewtest;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Service;
import android.content.pm.ActivityInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.hardware.display.DisplayManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Vibrator;
import android.os.VibratorManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements
        View.OnClickListener,
        AdapterView.OnItemSelectedListener,
        SurfaceHolder.Callback,
        DisplayManager.DisplayListener {
    private static final String TAG = "lzl-test-RefreshRateSurfaceViewTest";
    private Vibrator mVibrator;
    private TextView mTextViewInfo;
    private Spinner mSpinnerSystemSupportedRefreshRates, mSpinnerAppDrawFrequencySelect;
    private EditText mEditTextNumber;
    private Button mButton;

    private Display mDisplay;
    private Display.Mode mActiveMode;
    private Display.Mode[] mSupportedModes;
    private ArrayAdapter<Integer> mArrayAdapterSystemSelectableFps;
    private Integer[] mSystemSelectableFps;
    private int mSystemSelectedFps = 0;

    private ArrayAdapter<Integer> mArrayAdapterAppSelectableDrawFrequency;
    private Integer[] mAppSelectableDrawFrequency = {1, 5, 10, 24, 25, 30, 40, 50, 60, 90, 120, 144};
    private int mAppSelectedDrawFrequency = 0;
    private int mAppInputDrawFrequency = 0;
    private int mDoDrawFrequency = 0;

    private SurfaceView mSurfaceView;
    private SurfaceHolder mSurfaceHolder;
    private Paint mPaint = new Paint();
    private int mCircleRadius = 10;
    private boolean isRunning = false;
    private boolean isStart = false;
    private long mFrameCount = 0;
    private long mStartTimeMillis = 0, mStopTimeMillis = 0, mDrawCircleTimeMillis = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.d(TAG, "onCreate:---------------------------------------------------------start");

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_NOSENSOR); //设置屏幕不随手机旋转
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); //设置屏幕直向显示
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN); //设置屏幕全屏
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); //设置屏幕不进入休眠

        mDisplay = getWindowManager().getDefaultDisplay();
        mActiveMode = mDisplay.getMode();
        mTextViewInfo = (TextView) findViewById(R.id.textViewInfo);
        mTextViewInfo.setText("系统当前帧率：" + (int) mActiveMode.getRefreshRate() + "Hz, 分辨率: " + mActiveMode.getPhysicalWidth() + " x " + mActiveMode.getPhysicalHeight());

        mSpinnerSystemSupportedRefreshRates = (Spinner) findViewById(R.id.spinnerSystemSupportedRefreshRates);
        mSpinnerSystemSupportedRefreshRates.setOnItemSelectedListener(this);
        mSpinnerAppDrawFrequencySelect = (Spinner) findViewById(R.id.spinnerAppDrawFrequencySelect);
        mSpinnerAppDrawFrequencySelect.setOnItemSelectedListener(this);

        mSupportedModes = getWindowManager().getDefaultDisplay().getSupportedModes();
        ArrayList<Integer> listFps = new ArrayList<>();
        listFps.add((int)mSupportedModes[0].getRefreshRate());
        for (int i = 0; i < mSupportedModes.length; i++) {
            boolean found = false;
            Log.d(TAG, "getSupportedModes: " + mSupportedModes[i].toString());
            for (int index = 0; index < listFps.size(); index++)  {
                if ((int)mSupportedModes[i].getRefreshRate() == listFps.get(index)) {
                    found = true;
                    break;
                }
            }
            if (!found)
                listFps.add((int)mSupportedModes[i].getRefreshRate());
        }
        mSystemSelectableFps = new Integer[listFps.size()];
        for (int i = 0; i < listFps.size(); i++) {
            mSystemSelectableFps[i] = (int)listFps.get(i);
        }
        mArrayAdapterSystemSelectableFps = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, mSystemSelectableFps);
        mArrayAdapterSystemSelectableFps.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); // 设置下拉选单的选项样式
        mSpinnerSystemSupportedRefreshRates.setAdapter(mArrayAdapterSystemSelectableFps); // 设置使用 Adapter 对象
        for (int i = 0; i < mSystemSelectableFps.length; i++) {
            if (mSystemSelectableFps[i].intValue() == (int)mActiveMode.getRefreshRate()) {
                mSpinnerSystemSupportedRefreshRates.setSelection(i);
                break;
            }
        }

        mArrayAdapterAppSelectableDrawFrequency = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, mAppSelectableDrawFrequency);
        mArrayAdapterAppSelectableDrawFrequency.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); // 设置下拉选单的选项样式
        mSpinnerAppDrawFrequencySelect.setAdapter(mArrayAdapterAppSelectableDrawFrequency); // 设置使用 Adapter 对象
        for (int i = 0; i < mAppSelectableDrawFrequency.length; i++) {
            if (mAppSelectableDrawFrequency[i].intValue() == 60) {
                mSpinnerAppDrawFrequencySelect.setSelection(i);
                break;
            }
        }

        mEditTextNumber = (EditText) findViewById(R.id.editTextNumber);

        mButton = (Button) findViewById(R.id.button);
        mButton.setOnClickListener(this);

        mSurfaceView = (SurfaceView) findViewById(R.id.surfaceView);
        mSurfaceHolder = mSurfaceView.getHolder();
        mSurfaceHolder.addCallback(this);

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            VibratorManager vibratorManager = (VibratorManager)getSystemService(VibratorManager.class);
            mVibrator = vibratorManager.getDefaultVibrator();
        } else {
            mVibrator = (Vibrator)getSystemService(Service.VIBRATOR_SERVICE);
        }

        /* 获取DisplayManager */
        DisplayManager displayManager = (DisplayManager) getSystemService(Service.DISPLAY_SERVICE);
        /* 注册DisplayManager 的DisplayManager.DisplayListener 监听，监听display的变化，如添加/删除display，display帧率变化等 */
        displayManager.registerDisplayListener(this, null);
    }

    @Override
    public void onClick(View view) {
        isStart = !isStart;
        if (isStart) {
            // 获取用户输入的APP刷新率
            if (!mEditTextNumber.getText().toString().isEmpty())
                mAppInputDrawFrequency = Integer.parseInt(mEditTextNumber.getText().toString());
            else
                mAppInputDrawFrequency = 0;

            mDoDrawFrequency = (mAppInputDrawFrequency != 0) ? mAppInputDrawFrequency : mAppSelectedDrawFrequency;

            mEditTextNumber.setEnabled(false);
            mSpinnerSystemSupportedRefreshRates.setEnabled(false);
            mSpinnerAppDrawFrequencySelect.setEnabled(false);

            mButton.setText("停止");
            Log.d(TAG, "按键按下：开始绘制");
            mVibrator.vibrate(80);
            start();
        } else {
            mButton.setText("启动");
            Log.d(TAG, "按键按下：停止绘制");
            stop();
            mVibrator.vibrate(80);

            mEditTextNumber.setEnabled(true);
            mSpinnerSystemSupportedRefreshRates.setEnabled(true);
            mSpinnerAppDrawFrequencySelect.setEnabled(true);
        }
    }

    // 开始绘制
    public void start() {
        isRunning = true;
        mFrameCount = 0;
        mDrawCircleTimeMillis = 0;
        mStartTimeMillis = System.currentTimeMillis();

        new Thread() {
            @Override
            public void run() {
                while (isRunning) {
                    drawCircle();
                    try {
                        long sleep_ms = (1000 / mDoDrawFrequency) - mDrawCircleTimeMillis;
                        Thread.sleep((sleep_ms > 0 )? sleep_ms : 1);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }.start();
    }
    // 停止绘制
    public void stop() {
        isRunning = false;
        mStopTimeMillis = System.currentTimeMillis();
        drawText();
    }

    // 绘制图形
    private void drawCircle() {
        long now = System.currentTimeMillis();
        if (mSurfaceHolder != null) {
            Canvas canvas = mSurfaceHolder.lockCanvas();
            if (canvas != null) {
                mFrameCount++;
                // 设置画布为灰色背景色
                canvas.drawARGB(255, 13, 61, 80);
                // 画圆
                canvas.drawCircle(canvas.getWidth() / 2, canvas.getWidth() / 2, mCircleRadius, mPaint);
                canvas.drawText("这是第" + mFrameCount + "帧", 20, canvas.getWidth() + 40, mPaint);

                if (mCircleRadius < canvas.getWidth() / 2) {
                    mCircleRadius++;
                } else {
                    mCircleRadius = 10;
                }
                if (canvas != null && mSurfaceHolder != null) {
                    mSurfaceHolder.unlockCanvasAndPost(canvas);
                }
            }
        }
        mDrawCircleTimeMillis = System.currentTimeMillis() - now;
    }

    private void drawText() {
        if (mSurfaceHolder != null) {
            Canvas canvas = mSurfaceHolder.lockCanvas();
            if (canvas != null) {
                long averageTimeNsV1 = 0, averageTimeNsV2 = 0;
                averageTimeNsV1 = 1000000 / mDoDrawFrequency;
                averageTimeNsV2 = (mStopTimeMillis - mStartTimeMillis) * 1000 / mFrameCount;
                canvas.drawText("帧数：" + mFrameCount + " 耗时：" + (mStopTimeMillis - mStartTimeMillis) + "(ms)",
                        20, canvas.getWidth() + 80, mPaint);
                canvas.drawText("理论：" + averageTimeNsV1/1000 + "." + averageTimeNsV1%1000 + "(ms)" +
                                ", 实际：" + averageTimeNsV2/1000 + "." + averageTimeNsV2%1000 + "(ms)",
                        20, canvas.getWidth() + 120, mPaint);
                if (canvas != null && mSurfaceHolder != null) {
                    mSurfaceHolder.unlockCanvasAndPost(canvas);
                }
            }
        }
    }

    @Override
    public void surfaceCreated(@NonNull SurfaceHolder surfaceHolder) {
        Log.d(TAG, "surfaceCreated...");
        if (mSurfaceHolder == null) {
            // 调用getHolder()方法获取SurfaceHolder
            mSurfaceHolder = mSurfaceView.getHolder();
            // 通过 SurfaceHolder.addCallback方法设置:实现SurfaceHolder.Callback回调接口
            mSurfaceHolder.addCallback(this);
        }
        mPaint.setAntiAlias(true); // 设置画笔为无锯齿
        mPaint.setColor(Color.RED); // 设置画笔的颜色
        mPaint.setStrokeWidth(10); // 设置画笔的线宽
        mPaint.setStyle(Paint.Style.FILL); // 设置画笔的类型。STROK表示空心，FILL表示实心
        mPaint.setTextSize(30);
    }

    @Override
    public void surfaceChanged(@NonNull SurfaceHolder surfaceHolder, int i, int i1, int i2) {
        Log.d(TAG, "surfaceChanged...");
    }

    @Override
    public void surfaceDestroyed(@NonNull SurfaceHolder surfaceHolder) {
        Log.d(TAG, "surfaceDestroyed...");
        Log.d(TAG, "surfaceDestroyed：停止绘制");
        mSurfaceHolder = null;
        isStart = false;
        mButton.setText("启动");
        stop();
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
        Log.d(TAG, "Spinner: onItemSelected: position = " + position + ", id = " + id);

        if (adapterView.getId() == R.id.spinnerSystemSupportedRefreshRates) {
            mSystemSelectedFps = mSystemSelectableFps[position].intValue();
            Log.d(TAG, "Spinner: mSystemSelectedFps:" + mSystemSelectedFps);
            int preferredDisplayModeId = 0;
            float preferredRefreshRate = 0f;
            for (Display.Mode mode : mSupportedModes) {
                if ((int)mode.getRefreshRate() == mSystemSelectedFps &&
                        mode.getPhysicalWidth() == mActiveMode.getPhysicalWidth() &&
                        mode.getPhysicalHeight() == mActiveMode.getPhysicalHeight()) {
                    Log.d(TAG, "find mode: " + mode.toString());
                    preferredDisplayModeId = mode.getModeId();
                    preferredRefreshRate = mode.getRefreshRate();
                }
            }
            if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                WindowManager.LayoutParams params = getWindow().getAttributes();
                Log.d(TAG, "preferredDisplayModeId: old = " + params.preferredDisplayModeId + ", new = " + preferredDisplayModeId);
                Log.d(TAG, "preferredRefreshRate: old = " + params.preferredRefreshRate + ", new = " + preferredRefreshRate);

                /* WindowManager.LayoutParams#preferredDisplayModeId */
                params.preferredDisplayModeId = preferredDisplayModeId;
                getWindow().setAttributes(params);

                /* WindowManager.LayoutParams#preferredRefreshRate */
                /*
                params.preferredRefreshRate = preferredRefreshRate;
                getWindow().setAttributes(params);
                */

                /* setFrameRate() */
                /*
                if (mSurfaceHolder != null) {
                    mSurfaceHolder.getSurface().setFrameRate(mSystemSelectedFps,
                            Surface.FRAME_RATE_COMPATIBILITY_FIXED_SOURCE,
                            Surface.CHANGE_FRAME_RATE_ONLY_IF_SEAMLESS);
                }
                */
            }

        } else if (adapterView.getId() == R.id.spinnerAppDrawFrequencySelect) {
            mAppSelectedDrawFrequency = mAppSelectableDrawFrequency[position].intValue();
            Log.d(TAG, "Spinner: mAppSelectedDrawFrequency:" + mAppSelectedDrawFrequency);
        } else {
            Log.e(TAG, "Unknown spinner id!");
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {
        Log.d(TAG, "onNothingSelected...");

    }

    @Override
    public void onDisplayAdded(int displayId) {
        Log.d(TAG, "onDisplayAdded...");

    }

    @Override
    public void onDisplayRemoved(int displayId) {
        Log.d(TAG, "onDisplayRemoved...");

    }

    @Override
    public void onDisplayChanged(int displayId) {
        Log.d(TAG, "onDisplayChanged...");

        mActiveMode = mDisplay.getMode();
        mTextViewInfo.setText("系统当前帧率：" + (int) mActiveMode.getRefreshRate() + "Hz, 分辨率: " + mActiveMode.getPhysicalWidth() + " x " + mActiveMode.getPhysicalHeight());

        for (int i = 0; i < mSystemSelectableFps.length; i++) {
            if (mSystemSelectableFps[i].intValue() == (int) mActiveMode.getRefreshRate()) {
                mSpinnerSystemSupportedRefreshRates.setSelection(i);
                break;
            }
        }
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(TAG, "onRestart...");
    }

    @Override
    public void onResume(){
        super.onResume();
        Log.d(TAG, "onResume...");
    }

    @Override
    public void onPause(){
        super.onPause();
        Log.d(TAG, "onPause...");
    }

    @Override
    public void onStop(){
        super.onStop();
        Log.d(TAG, "onStop...");
    }

    @Override
    public void onDestroy(){
        super.onDestroy();
        Log.d(TAG, "onDestroy...");
    }
}