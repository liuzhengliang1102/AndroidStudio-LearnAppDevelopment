package com.example.sufaceviewtest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.NonNull;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, SurfaceHolder.Callback {
    private final static String TAG = "lzl-test-MainActivity";
    private Button mButton;
    private SurfaceView mSurfaceView;
    private SurfaceHolder mSurfaceHolder;
    private Paint mPaint = new Paint();
    private int mCircleRadius = 10;
    private boolean isRunning = false;
    private boolean isStart = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.d(TAG, "onCreate...");

        // 获取 SurfaceView
        mSurfaceView = (SurfaceView) findViewById(R.id.surfaceView_main);
        // 调用getHolder()方法获取SurfaceHolder
        mSurfaceHolder = mSurfaceView.getHolder();
        // 通过 SurfaceHolder.addCallback方法设置:实现SurfaceHolder.Callback回调接口
        mSurfaceHolder.addCallback(this);

        // 绘图 启动/ 停止 按键
        mButton = (Button) findViewById(R.id.button_main_start);
        mButton.setOnClickListener(this);
        mButton.setText("启动");

        // 跳转到SurfaceView touch划线测试 的 按键
        findViewById(R.id.button_main_goto_next).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        // 绘图 启动/ 停止 按键
        if (v.getId() == R.id.button_main_start) {
            isStart = !isStart;
            if (isStart) {
                mButton.setText("停止");
                Log.d(TAG, "按键按下：开始绘制");
                start();
            } else {
                mButton.setText("启动");
                Log.d(TAG, "按键按下：停止绘制");
                stop();
            }
        } else if (v.getId() == R.id.button_main_goto_next) {
            // 跳转到SurfaceView touch划线测试
            startActivity(new Intent(this, SecondaryActivity.class));
        }
    }

    @Override
    public void surfaceCreated(@NonNull SurfaceHolder surfaceHolder) {
        Log.d(TAG, "surfaceCreated...");
        if (mSurfaceHolder == null) {
            // 调用getHolder()方法获取SurfaceHolder
            mSurfaceHolder = mSurfaceView.getHolder();
            // 通过 SurfaceHolder.addCallback方法设置:实现SurfaceHolder.Callback回调接口
            mSurfaceHolder.addCallback(this);
        }

        mPaint.setAntiAlias(true); // 设置画笔为无锯齿
        mPaint.setColor(Color.RED); // 设置画笔的颜色
        mPaint.setStrokeWidth(10); // 设置画笔的线宽
        mPaint.setStyle(Paint.Style.FILL); // 设置画笔的类型。STROK表示空心，FILL表示实心
        mPaint.setTextSize(30);
    }

    @Override
    public void surfaceChanged(@NonNull SurfaceHolder surfaceHolder, int i, int i1, int i2) {
        Log.d(TAG, "surfaceChanged...");
    }

    @Override
    public void surfaceDestroyed(@NonNull SurfaceHolder surfaceHolder) {
        Log.d(TAG, "surfaceDestroyed...");
        Log.d(TAG, "surfaceDestroyed：停止绘制");
        mSurfaceHolder = null;
        isStart = false;
        mButton.setText("启动");
        stop();
    }

    // 开始绘制
    public void start() {
        isRunning = true;
        new Thread() {
            @Override
            public void run() {
                while (isRunning) {
                    drawCircle();
                    try {
                        Thread.sleep(20);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }.start();
    }

    // 停止绘制
    public void stop() {
        isRunning = false;
    }

    // 绘制图形
    private void drawCircle() {
        long now = System.currentTimeMillis();
        if (mSurfaceHolder != null) {
            Canvas canvas = mSurfaceHolder.lockCanvas();
            if (canvas != null) {
                // 设置画布为灰色背景色
                canvas.drawARGB(255, 55, 55, 55);
                // 画圆
                canvas.drawCircle(canvas.getWidth() / 2, canvas.getWidth() / 2, mCircleRadius, mPaint);

                if (mCircleRadius < canvas.getWidth() / 2) {
                    mCircleRadius++;
                } else {
                    mCircleRadius = 10;
                }
                if (canvas != null && mSurfaceHolder != null)
                    mSurfaceHolder.unlockCanvasAndPost(canvas);
            }
        }
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(TAG, "onRestart...");
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d(TAG, "onResume...");
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d(TAG, "onPause...");
    }

    @Override
    public void onStop() {
        super.onStop();
        Log.d(TAG, "onStop...");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy...");
    }
}