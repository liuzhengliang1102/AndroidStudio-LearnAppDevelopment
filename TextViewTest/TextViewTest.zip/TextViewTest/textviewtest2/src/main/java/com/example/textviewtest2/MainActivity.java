package com.example.textviewtest2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Scroller;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, View.OnLongClickListener {
    private final static String TAG = "lzl-test";

    private TextView mTextViewSetOnClickListener;
    private Boolean isRedColor = false;

    private TextView mTextViewEllipsize;
    private int mCount = 0;

    private TextView mTextViewMarquee;
    private boolean isPaused = false;

    private TextView mTextViewScrollable;
    private int mAddTextCount = 0;

    private String[] mStrings = {
            "黄药师：能不能请你喝碗酒？",
            "盲剑客：我今天只想喝水。",
            "黄药师：我以前好象见过你？",
            "盲剑客：何止见过，你曾经是我最好的朋友，但是现在已经不是啦。你来这儿干什么？",
            "黄药师：前不久，我遇到一个人，她送给我一坛酒，她说叫“醉生梦死”，喝了之后，不管以前干过什么也会全忘了。我很奇怪，为什么会有这样的酒，我喝了之后发觉真的很有效，不知你有没有兴趣试试？",
            "盲剑客：你知道喝酒跟喝水的分别吗？酒，越喝越暖，水会越喝越寒。",
            "黄药师：我们还会再见吗？",
            "盲剑客：不会！",
            "盲剑客（独白）：我曾经发过誓，如果再让我碰到这个人，我一定会杀了他。但是我没有这样做， 因为我见他的时候，眼睛已经看不见东西了。",
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_NOSENSOR); //设置屏幕不随手机旋转
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); //设置屏幕竖屏显示

        /* 测试TextView点击效果 */
        mTextViewSetOnClickListener = (TextView) findViewById(R.id.textViewSetOnClickListener);
        mTextViewSetOnClickListener.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (v.getId() == R.id.textViewSetOnClickListener) {
                    isRedColor = !isRedColor;
                    if (isRedColor) {
                        mTextViewSetOnClickListener.setTextColor(Color.RED);
                    } else {
                        mTextViewSetOnClickListener.setTextColor(Color.BLUE);
                    }
                }
            }
        });

        /* 测试TextView省略显示，点击改变省略方式 */
        mTextViewEllipsize = (TextView) findViewById(R.id.textViewEllipsize);
        mTextViewEllipsize.setSingleLine(true);
        mTextViewEllipsize.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (v.getId() == R.id.textViewEllipsize) {
                    mCount++;
                    if (mCount >= 4)
                        mCount = 1;
                    switch (mCount) {
                        case 1:
                            mTextViewEllipsize.setEllipsize(TextUtils.TruncateAt.START);
                            mTextViewEllipsize.setTextColor(Color.RED);
                            Toast.makeText(getApplicationContext(), "省略文本开始部分，省略号在开头", 500).show();
                            break;
                        case 2:
                            mTextViewEllipsize.setEllipsize(TextUtils.TruncateAt.MIDDLE);
                            mTextViewEllipsize.setTextColor(Color.GREEN);
                            Toast.makeText(getApplicationContext(), "省略文本中间部分，省略号在中间", 500).show();
                            break;
                        case 3:
                            mTextViewEllipsize.setEllipsize(TextUtils.TruncateAt.END);
                            mTextViewEllipsize.setTextColor(Color.BLUE);
                            Toast.makeText(getApplicationContext(), "省略文本结尾部分，省略号在尾部", 500).show();
                            break;
                        default:
                            break;
                    }
                }
            }
        });

        /* 测试TextView跑马灯滚动效果 */
        mTextViewMarquee = (TextView) findViewById(R.id.textViewMarquee);
        mTextViewMarquee.setTextColor(Color.RED);
        mTextViewMarquee.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        mTextViewMarquee.requestFocus(); // 强制获得焦点，让跑马灯滚起来
        mTextViewMarquee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (v.getId() == R.id.textViewMarquee) {
                    isPaused = !isPaused;
                    if (isPaused) {
                        mTextViewMarquee.setFocusable(false); // 不允许获得焦点
                        mTextViewMarquee.setFocusableInTouchMode(false); // 不允许在触摸时获得焦点
                    } else {
                        mTextViewMarquee.setFocusable(true); // 允许获得焦点
                        mTextViewMarquee.setFocusableInTouchMode(true); // 允许在触摸时获得焦点
                        mTextViewMarquee.requestFocus(); // 强制获得焦点，让跑马灯滚起来
                    }
                }
            }
        });

        /* 测试TextView垂直滚动显示效果，点击添加文本，长按删除 */
        mTextViewScrollable = (TextView) findViewById(R.id.textViewScrollable);
        mTextViewScrollable.setLines(8);
        mTextViewScrollable.setMaxLines(10);
        mTextViewScrollable.setBackgroundColor(Color.GRAY);
        // 设置内部文字的对齐方式
        mTextViewScrollable.setGravity(Gravity.LEFT | Gravity.BOTTOM);
        // 设置内部文本的移动方式为滚动形式
        mTextViewScrollable.setMovementMethod(new ScrollingMovementMethod());
        mTextViewScrollable.setOnClickListener(this);
        mTextViewScrollable.setOnLongClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.textViewScrollable ) {
            Log.d(TAG, "mStrings.length:" + mStrings.length);
            String string = String.format("%s\n%s %s", mTextViewScrollable.getText().toString(), getNowTimeMs(), mStrings[mAddTextCount]);
            mTextViewScrollable.setText(string);
            mAddTextCount++;
            if (mAddTextCount >= mStrings.length) {
                mAddTextCount = 0;
            }
        }
    }

    @Override
    public boolean onLongClick(View v) {
        if (v.getId() == R.id.textViewScrollable) {
            mTextViewScrollable.setText("");
        }
        return true;
    }

    private String getNowTimeMs() {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm:ss:SSS");
        return simpleDateFormat.format(new Date());
    }
}